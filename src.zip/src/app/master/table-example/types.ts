export interface ProductType {
  id?: string | null | undefined
  name: string
  description: string
  type: string
  created_at?: string | null | undefined
}
